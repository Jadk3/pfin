<?php
	/*conexión a servidor ceti*/
	$conexion=mysqli_connect("localhost","adoptamiwos","f0cb0bd70", "adoptamiwos") or die("No se estableció la conexión");
	

	/*conexión a localhost
	$conexion=mysqli_connect("localhost","root","", "yeren") or die("No se estableció la conexión");
	*/
?>